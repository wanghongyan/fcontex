//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Tetris.rc
//
#define IDI_ICON1                       101
#define IDS_BOX1                        101
#define IDS_STATUSBAR                   101
#define IDM_UP                          101
#define IDR_MENU1                       102
#define IDS_BOX2                        102
#define IDM_DOWN                        102
#define IDM_LEFT                        103
#define IDM_RIGHT                       104
#define IDR_TOOLBAR1                    115
#define IDB_BITMAP1                     117
#define IDB_BITMAP2                     120
#define IDB_BITMAP3                     121
#define IDB_BITMAP4                     122
#define IDB_BITMAP5                     123
#define IDB_BITMAP6                     124
#define IDB_BITMAP7                     125
#define IDB_BITMAP8                     126
#define IDB_BITMAP9                     127
#define IDD_DIALOG1                     128
#define IDD_DIALOG2                     129
#define IDR_WAVE1                       141
#define IDR_WAVE2                       142
#define IDD_DIALOG3                     144
#define IDC_RADIO1                      1003
#define IDC_RADIO2                      1004
#define IDC_RADIO3                      1005
#define IDM_NEW                         40001
#define IDM_PAUSE                       40002
#define IDM_STOP                        40003
#define IDM_EXIT                        40004
#define IDM_ABOUT                       40007
#define IDM_HELP                        40008
#define IDM_MUSIC                       40010
#define IDM_MUSIC1                      40011
#define IDM_MUSIC2                      40012
#define IDM_MUSICOFF                    40013

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         40014
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
